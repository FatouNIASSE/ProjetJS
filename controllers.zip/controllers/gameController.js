// Importation du modèle des niveaux
// Le modèle contient les données des niveaux et les fonctions associées.
const levelModel = require("../models/levelModel");

// Initialisation de l'index du niveau actuel
// `currentLevelIndex` garde une trace du niveau actuellement joué.
let currentLevelIndex = 0;

// Fonction pour obtenir les détails du niveau actuel
// Utilise le modèle pour récupérer les informations du niveau correspondant à `currentLevelIndex`.
const getLevel = () => levelModel.getLevel(currentLevelIndex);

// Fonction pour vérifier la réponse de l'utilisateur
// Compare la réponse donnée par l'utilisateur avec la réponse correcte du niveau actuel.
// Les réponses sont converties en minuscules pour éviter les problèmes de casse.
const checkAnswer = (userAnswer) =>
  userAnswer.toLowerCase() === getLevel().answer.toLowerCase();

// Fonction pour passer au niveau suivant
// Incrémente `currentLevelIndex` si un niveau suivant existe.
// Retourne `true` si le niveau est incrémenté, `false` si le joueur est au dernier niveau.
const nextLevel = () => {
  if (currentLevelIndex + 1 < levelModel.getTotalLevels()) {
    currentLevelIndex++; // Passe au niveau suivant
    return true; // Indique que la progression est réussie
  }
  return false; // Indique qu'il n'y a plus de niveaux à jouer
};

// Fonction pour réinitialiser le jeu
// Remet `currentLevelIndex` à 0 pour redémarrer le jeu depuis le premier niveau.
const resetGame = () => {
  currentLevelIndex = 0;
};

// Exportation des fonctions
// Ces fonctions sont utilisées dans d'autres fichiers pour contrôler la logique du jeu.
module.exports = {
  getLevel, // Récupérer le niveau actuel
  checkAnswer, // Vérifier si la réponse utilisateur est correcte
  nextLevel, // Passer au niveau suivant
  resetGame, // Réinitialiser le jeu
};

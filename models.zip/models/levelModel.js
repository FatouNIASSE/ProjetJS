// Définition des niveaux du jeu
// Chaque niveau contient une image et une réponse correcte associée.
const levels = [
  { image: "images/matin.png", answer: "matin" },  // Niveau 1 : Image du matin, réponse "matin".
  { image: "images/souris.png", answer: "souris" }, // Niveau 2 : Image de souris, réponse "souris".
  { image: "images/terre.png", answer: "terre" },   // Niveau 3 : Image de la terre, réponse "terre".
  { image: "images/croix.png", answer: "croix" },   // Niveau 4 : Image de croix, réponse "croix".
  { image: "images/chaud.png", answer: "chaud" },   // Niveau 5 : Image représentant "chaud", réponse "chaud".
  { image: "images/frange.png", answer: "frange" }, // Niveau 6 : Image de frange, réponse "frange".
];

// Exportation des fonctions pour accéder aux niveaux
module.exports = {
  // Fonction pour récupérer un niveau en fonction de son index
  // Paramètre : `index` (entier) correspondant au niveau souhaité.
  // Retourne un objet contenant l'image et la réponse du niveau.
  getLevel: (index) => levels[index],

  // Fonction pour récupérer le nombre total de niveaux
  // Retourne un entier représentant le nombre total de niveaux disponibles.
  getTotalLevels: () => levels.length,
};

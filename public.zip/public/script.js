document.getElementById("start-button").addEventListener("click", () => {
  const username = document.getElementById("username").value.trim();
  if (username) {
    localStorage.setItem("userPseudo", username);
    document.getElementById("user-pseudo").textContent = username;
    document.getElementById("welcome-screen").style.display = "none";
    document.getElementById("game-screen").style.display = "block";
    loadLevel();
  } else {
    alert("Veuillez entrer un pseudo pour commencer.");
  }
});

let currentLevelIndex = 0;

// Charger un niveau
function loadLevel() {
  const level = window.api.getLevel(); // Appel à gameController via preload.js
  const answer = level.answer.toUpperCase();
  const imageContainer = document.getElementById("image-container");
  const wordContainer = document.getElementById("word-container");
  const lettersContainer = document.getElementById("letters-container");

  // Afficher l'image
  imageContainer.innerHTML = `<img src="${level.image}" alt="Indice">`;

  // Créer les cases pour le mot
  wordContainer.innerHTML = "";
  for (let i = 0; i < answer.length; i++) {
    wordContainer.innerHTML += `<div class="letter-box" data-index="${i}"></div>`;
  }

  // Mélanger et afficher les lettres proposées
  const shuffledLetters = shuffleArray([...answer, ...generateRandomLetters(10)]);
  lettersContainer.innerHTML = shuffledLetters
    .map(
      (letter) =>
        `<div class="letter" onclick="selectLetter(this)">${letter}</div>`
    )
    .join("");

  document.getElementById("feedback").textContent = ""; // Réinitialiser le feedback
}

// Mélanger un tableau
function shuffleArray(array) {
  return array.sort(() => Math.random() - 0.5);
}

// Générer des lettres aléatoires
function generateRandomLetters(count) {
  const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
  return Array.from({ length: count }, () =>
    alphabet.charAt(Math.floor(Math.random() * alphabet.length))
  );
}

// Sélectionner une lettre
function selectLetter(letterElement) {
  const letter = letterElement.textContent;
  const emptyBox = document.querySelector(".letter-box:not(.filled)");
  if (emptyBox) {
    emptyBox.textContent = letter;
    emptyBox.classList.add("filled");
    letterElement.style.visibility = "hidden";
    checkWord();
  }
}

// Vérifier le mot
function checkWord() {
  const level = window.api.getLevel(); // Appel à gameController
  const answer = level.answer.toUpperCase();
  const filledWord = Array.from(document.querySelectorAll(".letter-box"))
    .map((box) => box.textContent)
    .join("");

  const feedback = document.getElementById("feedback");

  if (filledWord.length === answer.length) {
    if (filledWord === answer) {
      feedback.textContent = "Bonne réponse !";
      feedback.style.color = "green";
      if (window.api.nextLevel()) {
        setTimeout(loadLevel, 1000); // Passer au niveau suivant après 1s
      } else {
        feedback.textContent = "Félicitations ! Vous avez terminé le jeu.";
      }
    } else {
      feedback.textContent = "Mauvaise réponse. Réessayez.";
      feedback.style.color = "red";
    }
  }
}

// Quitter le jeu
document.getElementById("quit-button").addEventListener("click", () => {
  window.api.resetGame(); // Appel à gameController
  document.getElementById("welcome-screen").style.display = "block";
  document.getElementById("game-screen").style.display = "none";
});
